﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Xml;
using System.Net;
using System.Security.Cryptography;
using System.Diagnostics;
using Nano.Common;
using Nano.Net;
using Nano.Json;
using Nano.Json.Expression;

namespace Nano.Kuaipan
{
	public class XmlPostBuilder
	{
		StringBuilder sb = new StringBuilder("<xLive>");

		public void AddArg(string key, object value)
		{
			string value_s = value.ToString();
			sb.Append("<").Append(key).Append(">");
			foreach (char ch in value_s)
			{
				if (ch < ' ')
					throw new NotImplementedException();
				switch (ch)
				{
					case '&':
						sb.Append("&amp;");
						break;
					case '<':
						sb.Append("&lt;");
						break;
					case '>':
						sb.Append("&gt;");
						break;
					case '\"':
						sb.Append("&quot;");
						break;
					case '\'':
						sb.Append("&apos;");
						break;
					default:
						sb.Append(ch);
						break;
				}
			}
			sb.Append("</").Append(key).Append(">");
		}

		public string Commit()
		{
			return sb.Append("</xLive>").ToString();
		}
	}

	public class ApiRequestBuilder
	{
		HttpClient m_client;
		HttpWebRequest m_req;
		XmlPostBuilder m_pb;

		public ApiRequestBuilder(HttpClient client, string url, int ver)
		{
			m_client = client;
			m_req = m_client.CreateRequest(url);
			m_req.Headers.Add("v", ver.ToString());
			m_pb = new XmlPostBuilder();
		}

		public XmlPostBuilder PostBuilder
		{
			get { return m_pb; }
		}

		public string Commit()
		{
			m_client.MakePost(m_req, HttpClient.MimeBinary, m_pb.Commit());
			HttpWebResponse response = m_client.GetResponse(m_req);
			return ResponseReader.ReadResponseText(response);
		}
	}

	public abstract class ApiResponse
	{
		protected string m_retCode;

		public virtual bool Succeeded
		{
			get { return m_retCode == "ok"; }
		}

		public string ReturnCode
		{
			get { return m_retCode; }
		}

		public ApiResponse(string respText)
		{
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(respText);

			XmlElement e = doc.DocumentElement;
			m_retCode = e.GetAttribute("result");

			if (Succeeded)
				ParseEntries(e, this.ParseMainEntry);
		}

		protected delegate void ParseEntryDelegate(string key, XmlElement e);

		protected static void ParseEntries(XmlElement eParent, ParseEntryDelegate f)
		{
			foreach (XmlNode node in eParent.ChildNodes)
			{
				XmlElement e = (XmlElement)node;
				f(e.Name, e);
			}
		}

		void ParseResults(XmlElement eDoc)
		{
			foreach (XmlNode node in eDoc.ChildNodes)
			{
				XmlElement e = (XmlElement)node;
				ParseMainEntry(e.Name, e);
			}
		}

		protected abstract void ParseMainEntry(string key, XmlElement e);
	}

	public class LoginResponse : ApiResponse
	{
		public int UserID = 0;
		public string NickName = null, Token = null;

		public LoginResponse(string resp) : base(resp) { }

		protected override void ParseMainEntry(string key, XmlElement e)
		{
			string value = e.InnerText;
			switch (key)
			{
				case "userId":
					UserID = Convert.ToInt32(value);
					break;
				case "nickName":
					NickName = value;
					break;
				case "token":
					Token = value;
					break;
			}
		}
	}

	public class GetMaxVersResponse : ApiResponse
	{
		public int OpVer = 0, ShareVer = 0, NoticeVer = 0;

		public GetMaxVersResponse(string resp) : base(resp) { }

		protected override void ParseMainEntry(string key, XmlElement e)
		{
			string value = e.InnerText;
			switch (key)
			{
				case "opVer":
					OpVer = Convert.ToInt32(value);
					break;
				case "shareVer":
					ShareVer = Convert.ToInt32(value);
					break;
				case "noticeVer":
					NoticeVer = Convert.ToInt32(value);
					break;
			}
		}
	}

	public class ServerFileItem
	{
		public bool IsDir = false, IsShared = false;
		public string FileID = null, ParentId = null, Name = null, Sha1 = null;
		public int Modifier = 0, OpVer = 0, FileVer = 0;
		public long Size = 0;
		public DateTime CreatedTime = DateTime.MinValue, ModifiedTime = DateTime.MinValue;
	}

	public class DirResponse : ApiResponse
	{
		public List<ServerFileItem> Files = new List<ServerFileItem>();

		public DirResponse(string resp) : base(resp) { }

		protected override void ParseMainEntry(string key, XmlElement e)
		{
			Debug.Assert(key == "file");
			if (key != "file")
				return;

			ServerFileItem fi = new ServerFileItem();
			ParseEntryDelegate f = delegate(string in_key, XmlElement in_e)
			{
				string value = in_e.InnerText;
				switch (in_key)
				{
					case "modTime":
						fi.ModifiedTime = DateTime.Parse(value);
						break;
					case "modifier":
						fi.Modifier = Convert.ToInt32(value);
						break;
					case "name":
						fi.Name = value;
						break;
					case "sha1":
						fi.Sha1 = value;
						break;
					case "opVer":
						fi.OpVer = Convert.ToInt32(value);
						break;
					case "parentId":
						fi.ParentId = value;
						break;
					case "createdTime":
						fi.CreatedTime = DateTime.Parse(value);
						break;
					case "shared":
						// shareid 字段是一个大整数
						fi.IsShared = value != "0";
						// fi.IsShared = Convert.ToInt32(value) != 0;
						break;
					case "fileVer":
						fi.FileVer = Convert.ToInt32(value);
						break;
					case "fileId":
						fi.FileID = value;
						break;
					case "type":
						fi.IsDir = value == "folder";
						break;
					case "size":
						fi.Size = Convert.ToInt64(value);
						break;
					default:
						Debug.Assert(false);
						break;
				}
			};
			ParseEntries(e, f);
			if (fi.FileID != null)	// Dir空目录时会有空记录产生
				Files.Add(fi);
		}
	}

	public class CreateDirResponse : ApiResponse
	{
		public long FileId = 0;

		public CreateDirResponse(string resp) : base(resp) { }

		protected override void ParseMainEntry(string key, XmlElement e)
		{
			string value = e.InnerText;
			switch (key)
			{
				case "fileId":
					FileId = Convert.ToInt64(value);
					break;
			}
		}
	}

	public class BaseApi
	{
		HttpClient m_httpClient = new HttpClient();

		public LoginResponse Login(string user, string password)
		{
			const string url = "http://api-filesys.wps.cn/xsvr/login/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("user", user);
			pb.AddArg("password", password);
			pb.AddArg("deviceId", "0");
			pb.AddArg("clientName", "yanggang-test");
			pb.AddArg("clientVersion", "1");

			string respText = req.Commit();
			return new LoginResponse(respText);
		}

		public DirResponse Dir(string token, string parent)
		{
			const string url = "http://api-filesys.wps.cn/xsvr/dir/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("token", token);
			pb.AddArg("fileId", parent);

			string respText = req.Commit();
			return new DirResponse(respText);
		}

		public CreateDirResponse CreateDir(string token, string parent, string name)
		{
			const string url = "http://api-filesys.wps.cn/xsvr/newFolder/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("token", token);
			pb.AddArg("parentId", parent);
			pb.AddArg("name", name);

			string respText = req.Commit();
			return new CreateDirResponse(respText);
		}

		public GetMaxVersResponse GetMaxVers(string token)
		{
			const string url = "http://api-filesys.wps.cn/xsvr/getMaxVers/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("token", token);

			string respText = req.Commit();
			return new GetMaxVersResponse(respText);
		}

		public DirResponse SyncFile(string token, int opv, int size)
		{
			const string url = "http://api-filesys.wps.cn/xsvr/syncFile/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("token", token);
			pb.AddArg("opVer", opv);
			pb.AddArg("size", size);

			string respText = req.Commit();
			return new DirResponse(respText);
		}
	}

	public class RequestUploadResponse : ApiResponse
	{
		public class Block
		{
			public string FileKey = null;
			public string ValueI = null, ValueI2 = null;
		}

		// Fields when return code is "autoCommit"
		public long FileID = 0;
		public int FileVer = 0, OpVer = 0;

		// Fields when return code is "ok"
		public string Stub = null;
		public string ValueA = null;
		public string UfaUrl = null;
		public List<Block> BlockList = null;

		public RequestUploadResponse(string resp)
			: base(resp)
		{
		}

		public override bool Succeeded
		{
			get
			{
				return m_retCode == "ok" || m_retCode == "autoCommit" || m_retCode == "targetExist";
			}
		}

		protected override void ParseMainEntry(string key, XmlElement e)
		{
			string value = e.InnerText;
			switch (key)
			{
				// Fields when code is "autoCommit"
				case "fileVer":
					FileVer = Convert.ToInt32(value);
					break;
				case "opVer":
					OpVer = Convert.ToInt32(value);
					break;
				case "fileId":
					FileID = Convert.ToInt64(value);
					break;

				// Fields when code is "ok"
				case "s":
					Stub = value;
					break;
				case "a":
					ValueA = value;
					break;
				case "u":
					UfaUrl = value;
					break;
				case "b":
					ParseBlock(e);
					break;
			}
		}

		void ParseBlock(XmlElement eBlock)
		{
			Debug.Assert(eBlock.Name == "b");
			Block block = new Block();

			ParseEntryDelegate f = delegate(string key, XmlElement e)
			{
				string value = e.InnerText;
				switch (key)
				{
					case "k":
						block.FileKey = value;
						break;
					case "i":
						block.ValueI = value;
						break;
					case "i2":
						block.ValueI2 = value;
						break;
					default:
						Debug.Assert(false);
						break;
				}
			};
			ParseEntries(eBlock, f);

			Debug.Assert(block.FileKey != null && block.ValueI != null);

			if (BlockList == null)
				BlockList = new List<Block>();
			BlockList.Add(block);
		}
	}

	public class RequestDownloadResponse : ApiResponse
	{
		public class Block
		{
			public string Id = null;
			public List<string> ValueA = new List<string>();
			public string ValueI = null;
			public string Key = null;
			public int Size = 0;
			public List<int> UfaIndices = new List<int>();
			public int ValueV = 0;
		}

		public class UfaItem
		{
			public string Addr = null;
			public int T = 0;
		}

		public int FileVer = 0, OpVer = 0;
		public string Stub = null, Sha1 = null;
		public DateTime MTime = DateTime.MinValue;
		public List<UfaItem> UfaItems = null;
		public List<Block> Blocks = null;

		public RequestDownloadResponse(string resp) : base(resp)
		{
		}

		protected override void ParseMainEntry(string key, XmlElement e)
		{
			string value = e.InnerText;
			switch (key)
			{				
				case "fileVer":
					FileVer = Convert.ToInt32(value);
					break;
				case "opVer":
					OpVer = Convert.ToInt32(value);
					break;
				case "s":
					Stub = value;
					break;
				case "modTime":
					MTime = DateTime.Parse(value);
					break;
				case "sha1":
					Sha1 = value;
					break;
				case "u":
					ParseUfaItems(value);
					break;
				case "b":
					ParseBlock(value);
					break;
			}			
		}

		void ParseUfaItems(string json)
		{
			JsonNode node = JsonParser.ParseText(json);
			Debug.Assert(node.NodeType == JsonNodeType.NodeList);
			UfaItems = new List<UfaItem>();
			foreach (JsonNode nodeItem in node.ChildNodes)
			{
				UfaItem item = new UfaItem();
				item.Addr = nodeItem["u"].TextValue;
				item.T = (int)nodeItem["t"].IntValue;
				UfaItems.Add(item);
			}
		}

		void ParseBlock(string json)
		{
			JsonNode node = JsonParser.ParseText(json);
			Debug.Assert(node.NodeType == JsonNodeType.NodeList);
			Blocks = new List<Block>();
			foreach (JsonNode nodeItem in node.ChildNodes)
			{
				Block item = new Block();
				nodeItem["a"].WalkChildren<string>(item.ValueA);
				item.Id = nodeItem["b"].TextValue;
				item.ValueI = nodeItem["i"].TextValue;
				item.Key = nodeItem["k"].TextValue;
				item.Size = (int)(long)nodeItem.TryGetChildValue("s");
				if (item.Size == 0)
					item.Size = Convert.ToInt32(item.Id.Substring(0, 6), 16);
				nodeItem["u"].WalkChildren<long>(value => item.UfaIndices.Add((int)value));
				item.ValueV = (int)nodeItem["v"].IntValue;
				Blocks.Add(item);
			}
		}
	}

	public class TransmitApi
	{
		HttpClient m_httpClient = new HttpClient();

		public class RequestUploadBlockInfo
		{
			public string BlockId = null, OHash2 = null;
		}

		public class RequestUploadMeta
		{
			public List<RequestUploadBlockInfo> Blocks = new List<RequestUploadBlockInfo>();
			public long Length = 0;
			public string OHash = null;
			public string UfaId = null;
		}

		public static RequestUploadMeta ComputeUploadFileMeta(Stream istream)
		{
			RequestUploadMeta meta = new RequestUploadMeta();
			meta.Length = istream.Length;
			istream.Seek(0, SeekOrigin.Begin);
			SHA1 shaF = SHA1.Create();
			string line = "";

			byte[] buffer = new byte[0x400000];
			long remain = meta.Length;
			while (remain > 0)
			{
				RequestUploadBlockInfo block = new RequestUploadBlockInfo();

				int chunk = istream.Read(buffer, 0, buffer.Length);
				Debug.Assert(chunk == (remain >= buffer.Length ? buffer.Length : (int)remain));

				SHA1 shaHash = SHA1.Create();
				byte[] digest = shaHash.ComputeHash(buffer, 0, chunk);
				string csha1 = BinaryValue.GetString(digest).ToLowerInvariant();
				line += csha1;
				block.BlockId = chunk.ToString("x6") + csha1;

				MD5 md5Hash = MD5.Create();
				digest = md5Hash.ComputeHash(buffer, 0, chunk);
				string cmd5 = BinaryValue.GetString(digest).ToLowerInvariant();
				digest = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(cmd5));
				block.OHash2 = BinaryValue.GetString(digest).ToLowerInvariant();

				shaF.TransformBlock(buffer, 0, chunk, buffer, 0);

				remain -= chunk;
				meta.Blocks.Add(block);
			}

			shaF.TransformFinalBlock(buffer, 0, 0);
			byte[] digestF = shaF.Hash;
			meta.OHash = BinaryValue.GetString(digestF).ToLowerInvariant();

			if (meta.Blocks.Count > 1)
			{
				SHA1 shaHash = SHA1.Create();
				byte[] digest = shaHash.ComputeHash(Encoding.UTF8.GetBytes(line));
				meta.UfaId = meta.Length.ToString("x8") + BinaryValue.GetString(digest);
			}
			else
				meta.UfaId = meta.Blocks[0].BlockId;

			return meta;
		}

		static string ComputeBlocksJsonString(List<RequestUploadBlockInfo> blocks)
		{
			JE expr = JE.New() + JE.List();
			foreach (RequestUploadBlockInfo block in blocks)
			{
				expr = expr +
					JE.Dict() +
						JE.Pair("b", block.BlockId) +
						JE.Pair("m", block.OHash2) +
					JE.EDict();
			}
			expr = expr + JE.EList();
			return expr.GetString();
		}

		public RequestUploadResponse RequestUploadX(string token, long fileId, long parentId, string name, int fileVer, long size, string sha1, DateTime modTime, List<RequestUploadBlockInfo> blocks)
		{
			if (size >= 0x2000000000000000L)
				throw new ArgumentOutOfRangeException("File too big");

			const string url = "http://api-filesys.wps.cn/xsvr/requestUploadX/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("token", token);
			pb.AddArg("fileId", fileId);
			pb.AddArg("fileVer", fileVer);
			pb.AddArg("parentId", parentId);
			pb.AddArg("name", name);
			pb.AddArg("size", size);
			pb.AddArg("sha1", sha1);
			pb.AddArg("modTime", modTime.ToString("yyyy-MM-dd HH:mm:ss"));
			string blocksJson = ComputeBlocksJsonString(blocks);
			pb.AddArg("blockInfos", blocksJson);

			string respText = req.Commit();
			RequestUploadResponse r = new RequestUploadResponse(respText);
			return r;
		}

		public RequestDownloadResponse RequestDownloadX(string token, long fileId, int fileVer)
		{
			const string url = "http://api-filesys.wps.cn/xsvr/requestDownloadXL/";
			ApiRequestBuilder req = new ApiRequestBuilder(m_httpClient, url, 2);
			XmlPostBuilder pb = req.PostBuilder;
			pb.AddArg("token", token);
			pb.AddArg("fileId", fileId);
			pb.AddArg("fileVer", fileVer);

			string respText = req.Commit();
			RequestDownloadResponse r = new RequestDownloadResponse(respText);
			return r;
		}

		public void DownloadBlock(string stub, RequestDownloadResponse.Block block, List<RequestDownloadResponse.UfaItem> ufaItems, Stream ostream)
		{
			const int iUfa = 0;
			RequestDownloadResponse.UfaItem ufaItem = ufaItems[iUfa];
			string url = string.Format("{0}downloadBlock", ufaItem.Addr);
			JE expr = JE.New() + 
				JE.Dict() +
					JE.Pair("stub", stub) +
					JE.Pair("id", block.ValueI) +
					JE.Pair("addr", block.ValueA[iUfa]) +
					JE.Pair("size", block.Size.ToString()) +
					JE.Pair("vcode", block.ValueV) +
				JE.EDict();
			string json = expr.GetString();

			var req = m_httpClient.CreateRequest(url);
			m_httpClient.MakePost(req, HttpClient.MimeBinary, json);

			var response = (HttpWebResponse)m_httpClient.GetResponse(req);
			Debug.Assert(response.StatusCode == HttpStatusCode.OK);
			ResponseReader.SaveStream(response, ostream);
		}

		public void DownloadBlock(RequestDownloadResponse r, int index, Stream ostream)
		{
			DownloadBlock(r.Stub, r.Blocks[index], r.UfaItems, ostream);
		}
	}
}
