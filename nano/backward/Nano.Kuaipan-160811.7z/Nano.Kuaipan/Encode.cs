﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Nano.Common;

namespace Nano.Kuaipan
{
	public class FileEncoderV2
	{
		// X64
		[DllImport("LZMA-vc2010-x64", CharSet = CharSet.Unicode, EntryPoint = "LzmaUncompress")]
		public static extern int LzmaUncompress64(byte[] dest, ref long destLen, byte[] src, ref long srcLen, byte[] props, long propsSize);

		// X86
		[DllImport("LZMA-vc2010-x86", CharSet = CharSet.Unicode, EntryPoint = "LzmaUncompress")]
		public static extern int LzmaUncompress32(byte[] dest, ref long destLen, byte[] src, ref long srcLen, byte[] props, long propsSize);

		delegate int LzmaUncompressDelegate(byte[] dest, ref long destLen, byte[] src, ref long srcLen, byte[] props, long propsSize);
		LzmaUncompressDelegate LzmaUncompress;

		byte[] m_bufS, m_bufT;
		Aes m_aes;

		bool m_fCompress;
		uint m_sizeOrg;
		byte[] m_shaOrg;
		ulong m_hint;
		uint m_padding;

		FileEncoderV2(string k)
		{
			if (Environment.Is64BitOperatingSystem)
				LzmaUncompress = LzmaUncompress64;
			else
				LzmaUncompress = LzmaUncompress32;

			m_bufS = new byte[4096];
			m_bufT = new byte[4096];

			byte[] key = FileKeyFromText(k);
			m_aes = Aes.Create();
			m_aes.Key = key;
			m_aes.Mode = CipherMode.ECB;
			m_aes.Padding = PaddingMode.None;
		}

		public static byte[] FileKeyFromText(string keyText)
		{
			Debug.Assert(keyText.Length == 64);
			byte[] key = new byte[keyText.Length >> 1];
			for (int i = 0; i < key.Length; ++i)
			{
				key[i] = (byte)
					(BinaryValue.ConvertToDigit(keyText[i + i + 1]) << 4 |
					BinaryValue.ConvertToDigit(keyText[i + i]));
			}
			return key;
		}

		void DecodeHeader()
		{
			uint mark = BitConverter.ToUInt32(m_bufS, 0);
			Debug.Assert(mark == 0x3046534B);	// File mark

			uint flags = BitConverter.ToUInt32(m_bufS, 4);
			Debug.Assert((flags & 0xFFFFFEFF) == 0x201);	// Flags, version = 1, encrypted
			m_fCompress = (flags & 0x100) != 0;

			m_sizeOrg = BitConverter.ToUInt32(m_bufS, 8);
			m_shaOrg = new byte[20];
			Array.Copy(m_bufS, 12, m_shaOrg, 0, 20);

			m_hint = BitConverter.ToUInt64(m_bufS, 32);
			Debug.Assert(m_hint == 0);

			m_padding = m_bufS[40];
			Debug.Assert(m_padding < 16);
		}

		void Decrypt(Stream m_ss, Stream m_st)
		{
			m_ss.Seek(0, SeekOrigin.Begin);
			Debug.Assert(m_st.Length == 0);

			int cb = m_ss.Read(m_bufS, 0, 4096);
			Debug.Assert(cb > 64);
			DecodeHeader();

			ICryptoTransform t = m_aes.CreateDecryptor();
			if (t.TransformBlock(m_bufS, 64, cb - 64, m_bufT, 64) != cb - 64)
				throw new IOException("Decryption error");
			m_st.Write(m_bufT, 64, cb - 64);

			while ((cb = m_ss.Read(m_bufS, 0, 4096)) != 0)
			{
				if (t.TransformBlock(m_bufS, 0, cb, m_bufT, 0) != cb)
					throw new IOException("Decryption error");
				m_st.Write(m_bufT, 0, cb);
			}

			m_st.SetLength(m_st.Length - m_padding);
		}

		void Decompress(Stream istream, Stream ostream)
		{
			istream.Seek(0, SeekOrigin.Begin);
			Debug.Assert(ostream.Length == 0);
			byte[] buffer = new byte[0x400000];	// 4MB

			if (m_fCompress)
			{
				long isize = istream.Length;
				byte[] props = new byte[5];
				int cbOp = istream.Read(props, 0, props.Length);
				Debug.Assert(cbOp == props.Length);
				byte[] sizeLE = new byte[8];
				cbOp = istream.Read(sizeLE, 0, sizeLE.Length);
				Debug.Assert(cbOp == sizeLE.Length);
				isize -= props.Length + sizeLE.Length;

				byte[] ibuffer = new byte[isize];
				cbOp = istream.Read(ibuffer, 0, (int)isize);
				Debug.Assert(cbOp == isize);

				long osize = BitConverter.ToInt64(sizeLE, 0);
				byte[] obuffer = new byte[osize];
				int r = LzmaUncompress(obuffer, ref osize, ibuffer, ref isize, props, props.Length);
				if (r != 0)
					throw new Exception("LZMA decode failed");

				ostream.Write(obuffer, 0, (int)osize);
			}
			else
			{
				Nano.Net.ResponseReader.CopyStream(istream, ostream, buffer);
			}
		}

		public bool Verify(Stream ostream)
		{
			if (ostream.Length != m_sizeOrg)
				return false;

			SHA1 sha1 = SHA1.Create();
			ostream.Seek(0, SeekOrigin.Begin);
			byte[] digest = sha1.ComputeHash(ostream);

			for (int i = 0; i < digest.Length; ++i)
				if (digest[i] != m_shaOrg[i])
					return false;

			return true;
		}

		public static void DecodeFile(Stream istream, Stream ostream, string k)
		{
			FileEncoderV2 o = new FileEncoderV2(k);
			MemoryStream tstream = new MemoryStream();
			o.Decrypt(istream, tstream);
			o.Decompress(tstream, ostream);
			Debug.Assert(o.Verify(ostream));
		}
	}
}
