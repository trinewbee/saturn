﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Diagnostics;
using Nano.Common.AppEnv;

namespace Nano.Kuaipan
{
	public class KClientException : Exception
	{
		public KClientException(string message)
			: base(message)
		{
		}
	}

	public class UserFileItem
	{
		public long FileId, ParentId;
		public string Name;
		public bool IsDir;
		public long Size;
		public string Sha1;
		public List<UserFileItem> Children;
		public int Flags;
		public object Tag = null;

		public UserFileItem(long _fid, long _parent, string _name, bool _isdir)
		{
			FileId = _fid;
			ParentId = _parent;
			Name = _name;
			IsDir = _isdir;
			Size = 0;
			Sha1 = null;
			Children = _isdir ? new List<UserFileItem>() : null;
			Flags = 0;
		}

		public UserFileItem(ServerFileItem sfi)
		{
			FileId = Convert.ToInt64(sfi.FileID);
			ParentId = sfi.ParentId.Length != 0 ? Convert.ToInt64(sfi.ParentId) : 0;
			Name = sfi.Name;
			IsDir = sfi.IsDir;
			Size = sfi.Size;
			Sha1 = sfi.Sha1;			
			Children = IsDir ? new List<UserFileItem>() : null;
			Flags = 0;
		}

		public void AddChild(UserFileItem fi)
		{
			Debug.Assert((fi.ParentId == FileId || FileId == 0) && IsDir);
			Children.Add(fi);
		}

		public UserFileItem GetChild(string name)
		{
			Debug.Assert(IsDir);
			foreach (UserFileItem fiSub in Children)
			{
				if (string.Compare(fiSub.Name, name, StringComparison.OrdinalIgnoreCase) == 0)
					return fiSub;
			}
			return null;
		}

		public UserFileItem Touch(string path, char separator)
		{
			if (path.Length == 0)
				return this;

			Debug.Assert(path[0] != separator);
			int pos = 0;
			UserFileItem fi = this;
			while (pos < path.Length)
			{
				int pos2 = path.IndexOf(separator, pos);
				Debug.Assert(pos2 != pos);
				if (pos2 < 0)
					pos2 = path.Length;

				string name = path.Substring(pos, pos2 - pos);
				Debug.Assert(name[0] != '.');
				fi = fi.GetChild(name);
				if (fi == null)
					return null;

				pos = pos2 + 1;
			}
			return fi;
		}
	}

	public class UserModel
	{
		public UserFileItem Root = null;
		public object Tag = null;

		public UserFileItem Touch(string path, char separator)
		{
			Debug.Assert(path[0] == separator);
			return Root.Touch(path.Substring(1), separator);
		}
	}

	public class UserModelBuilder
	{
		BaseApi m_api;
		AppInteract m_interact;

		public UserModelBuilder(BaseApi api, AppInteract interact)
		{
			m_api = api;
			m_interact = interact;
		}

		#region Build using SYNC sematics

		public UserModel BuildSync(string token, out int opvMax)
		{
			UserModel model = new UserModel();
			model.Root = new UserFileItem(0, -1, null, true);

			opvMax = GetMaxOpv(token);

			Dictionary<long, UserFileItem> fimap = new Dictionary<long, UserFileItem>();
			fimap.Add(0, model.Root);
			DoSync(token, opvMax, fimap);

			BuildTree(fimap);
			CheckCompletion(model, fimap);

			return model;
		}

		int GetMaxOpv(string token)
		{
			GetMaxVersResponse rMaxVers = m_api.GetMaxVers(token);
			if (!rMaxVers.Succeeded)
				throw new KClientException("getMaxVers");

			int opvMax = rMaxVers.OpVer;
			return opvMax;
		}

		void DoSync(string token, int opvMax, Dictionary<long, UserFileItem> fimap)
		{			
			const int syncStep = 512;
			for (int opv = 0; opv < opvMax; )
			{
				DirResponse rDir = m_api.SyncFile(token, opv, syncStep);
				if (!rDir.Succeeded)
					throw new KClientException("syncFile");

				if (rDir.Files.Count != 0)
				{
					List<ServerFileItem> sfis = rDir.Files;
					foreach (ServerFileItem sfi in sfis)
					{
						UserFileItem fi = new UserFileItem(sfi);
						fimap.Add(fi.FileId, fi);
					}
					opv = sfis[sfis.Count - 1].OpVer;
				}
				else
					opv = opvMax;
			}			
		}

		void BuildTree(Dictionary<long, UserFileItem> fimap)
		{
			foreach (KeyValuePair<long, UserFileItem> entry in fimap)
			{
				UserFileItem fi = entry.Value;
				if (fi.FileId == 0)
					continue;

				UserFileItem pfi;
				if (!fimap.TryGetValue(fi.ParentId, out pfi))
				{
					m_interact.Write("Warning: Parent not found, fid={0}, parent={1}", fi.FileId, fi.ParentId);
					pfi = fimap[0];
				}
				Debug.Assert(pfi.IsDir);
				pfi.AddChild(fi);
			}
		}

		void CheckCompletion(UserModel model, Dictionary<long, UserFileItem> fimap)
		{
			foreach (UserFileItem fi in fimap.Values)
				fi.Flags = 0;

			MarkTreeItem(model.Root, 0, 1);

			foreach (UserFileItem fi in fimap.Values)
			{
				Debug.Assert(fi.Flags == 1);
				fi.Flags = 0;
			}
		}

		void MarkTreeItem(UserFileItem fi, int oldValue, int newValue)
		{
			Debug.Assert(fi.Flags == oldValue);
			fi.Flags = newValue;
			if (fi.IsDir)
			{
				foreach (UserFileItem subfi in fi.Children)
					MarkTreeItem(subfi, oldValue, newValue);
			}
		}

		#endregion

		#region Save user file model

		public void SaveModel(UserModel model, XmlWriter wr)
		{
			SaveFileItem(model.Root, wr);
		}

		void SaveFileItem(UserFileItem fi, XmlWriter wr)
		{
			wr.WriteStartElement(fi.IsDir ? "folder" : "file");
			wr.WriteAttributeString("fid", fi.FileId.ToString());
			wr.WriteAttributeString("parent", fi.ParentId.ToString());
			wr.WriteAttributeString("name", fi.Name);

			if (fi.IsDir)
			{
				foreach (UserFileItem subfi in fi.Children)
					SaveFileItem(subfi, wr);
			}
			else
			{
				wr.WriteAttributeString("size", fi.Size.ToString());
				wr.WriteAttributeString("hash", fi.Sha1);
			}

			wr.WriteEndElement();
		}

		#endregion

		#region Load user file model

		public UserModel LoadModel(XmlElement e)
		{
			UserModel model = new UserModel();
			model.Root = new UserFileItem(0, -1, null, true);
			LoadFolderItem(model.Root, e);
			return model;
		}

		void LoadFolderItem(UserFileItem fi, XmlElement e)
		{
			Debug.Assert(e.Name == "folder" && fi.IsDir);
			foreach (XmlNode nodeSub in e.ChildNodes)
			{
				if (nodeSub.NodeType != XmlNodeType.Element)
					continue;

				XmlElement eSub = (XmlElement)nodeSub;
				bool isdir = eSub.Name == "folder";
				long fid = Convert.ToInt64(eSub.GetAttribute("fid"));
				long parent = Convert.ToInt64(eSub.GetAttribute("parent"));
				string name = eSub.GetAttribute("name");
				UserFileItem fiSub = new UserFileItem(fid, parent, name, isdir);
				fi.AddChild(fiSub);

				if (isdir)
				{
					LoadFolderItem(fiSub, eSub);
				}
				else
				{
					fiSub.Size = Convert.ToInt64(eSub.GetAttribute("size"));
					fiSub.Sha1 = eSub.GetAttribute("hash");
				}
			}
		}

		#endregion
	}
}
