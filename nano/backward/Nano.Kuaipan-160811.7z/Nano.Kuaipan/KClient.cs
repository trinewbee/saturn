﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using Nano.Common.AppEnv;

namespace Nano.Kuaipan
{
	public class KClient
	{
		BaseApi m_api = new BaseApi();
		TransmitApi m_transmit = new TransmitApi();
		ProgressBoard m_prog = new ProgressBoard();
		int m_userid = 0;
		string m_token = null;

		#region Properties

		public BaseApi Api
		{
			get { return m_api; }
		}

		public TransmitApi Transmit
		{
			get { return m_transmit; }
		}

		public ProgressBoard Progress
		{
			get { return m_prog; }
		}

		public int UserId
		{
			get { return m_userid; }
		}

		public string Token
		{
			get { return m_token; }
		}

		#endregion

		public KClient()
		{
		}

		public KClient(int userid, string token)
		{
			m_userid = userid;
			m_token = token;
		}

		public void Login(string user, string pass)
		{
			LoginResponse r = m_api.Login(user, pass);
			if (!r.Succeeded)
				throw new KClientException("Login failed, " + r.ReturnCode);
			m_userid = r.UserID;
			m_token = r.Token;
		}

		public GetMaxVersResponse GetMaxVers()
		{
			GetMaxVersResponse r = m_api.GetMaxVers(m_token);
			if (!r.Succeeded)
				throw new KClientException("GetMaxVers failed, " + r.ReturnCode);
			return r;
		}

		public interface IBlockCache
		{
			bool Exists(string id);
			void Add(string id, Stream istream);
			Stream Open(string id);
		}

		public class MemoryBlockCache : IBlockCache
		{
			Dictionary<string, Stream> m_map = new Dictionary<string, Stream>();

			public bool Exists(string id)
			{
				return m_map.ContainsKey(id);
			}

			public void Add(string id, Stream istream)
			{
				MemoryStream mstream = new MemoryStream((int)istream.Length);
				istream.Seek(0, SeekOrigin.Begin);
				Nano.Net.ResponseReader.CopyStream(istream, mstream, new byte[4096]);
			}

			public Stream Open(string id)
			{
				Stream istream;
				if (m_map.TryGetValue(id, out istream))
					return istream;
				return null;
			}
		}

		// To download latest version, set fver = 0
		public void Download(long fid, int fver, Stream ostream, IBlockCache bc, ProgressBoard.OnChange onchange)
		{
			RequestDownloadResponse rReq = m_transmit.RequestDownloadX(m_token, fid, fver);
			if (!rReq.Succeeded)
				throw new KClientException("RequestDownload failed, " + rReq.ReturnCode);

			m_prog.Reset(onchange);
			for (int i = 0; i < rReq.Blocks.Count; ++i)
			{
				string id = rReq.Blocks[i].Id;
				int size = Convert.ToInt32(id.Substring(0, 6), 16);
				string message = string.Format("Download {0} ({1} bytes)", id, size);
				m_prog.AddStep(message, size / 65536);	// avoid overflow in SUM
			}
			m_prog.CompleteInit();

			Debug.Assert(ostream.Length == 0);
			byte[] buffer = new byte[4096];
			for (int i = 0; i < rReq.Blocks.Count; ++i)
			{
				m_prog.EnterStep(i);
				RequestDownloadResponse.Block block = rReq.Blocks[i];
				Stream bstream;
				if (!bc.Exists(block.Id))
				{
					Stream tstream = new MemoryStream();
					m_transmit.DownloadBlock(rReq, i, tstream);

					bstream = new MemoryStream();
					FileEncoderV2.DecodeFile(tstream, bstream, block.Key);
					bc.Add(block.Id, bstream);
				}
				else
					bstream = bc.Open(block.Id);
				bstream.Seek(0, SeekOrigin.Begin);
				Nano.Net.ResponseReader.CopyStream(bstream, ostream, buffer);
			}
			m_prog.CompleteSteps();
		}
	}
}
